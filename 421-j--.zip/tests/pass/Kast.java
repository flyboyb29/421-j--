// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package pass;

public class Kast {

    public static void main(String[] args) {
        Object[] oa;
        oa = (Object[]) args;
        args = (String[]) oa;
    }

}
