package pass;

public class Literals {

	public static void main(String[] args) {
		
	}

}
