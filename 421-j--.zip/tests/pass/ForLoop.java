package pass;

public class ForLoop {

	public static void forLoop(int count) {
		int i;
		
		for (i = 0; i <= count; i++) {
			System.out.println("Hello World");
		}
	}
	
	public static void main(String[] args) {
		forLoop(n);
	}
	
	static int n = 5;
}
