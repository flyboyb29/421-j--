
package pass;

import java.lang.System;

public class DoWhile {

	public static void doWhile (int times) {
		int count = 0;
		
		do {
			System.out.println(count);
			count++;
		} while (count < times);
	}
	
	public static void main(String[] args) {
		
		doWhile(n);

	}
	
	static int n = 5;
}
