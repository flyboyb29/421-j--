package fail;

public class Operators {

	public static void main(String[] args) {
		= 
        > 
        < 
        ! 
        ~ 
        ? 
        : 
        ->
        == 
        >= 
        <= 
        != 
        && 
        || 
        ++ 
        --
        + 
        - 
        * 
        / 
        & 
        | 
        ^ 
        % 
        << 
        >> 
        >>>
        += 
        -= 
        *= 
        /= 
        &= 
        |= 
        ^= 
        %= 
        <<= 
        >>= 
        >>>=
	}

}
